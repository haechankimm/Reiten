/* =========================================================
   REITEN — 다국어(i18n)
   ---------------------------------------------------------
   기본 언어는 한국어이며, 한국어 원문 자체를 딕셔너리 키로 씁니다.
   따라서 ko 상태에서는 아무것도 치환하지 않고 마크업 그대로 보여줍니다.
   ========================================================= */

const LANG_KEY = "reiten_lang";
const LANGS = ["ko", "en", "ja"];
const LANG_LABEL = { ko: "한국어", en: "English", ja: "日本語" };

function getLang() {
  try {
    const l = localStorage.getItem(LANG_KEY);
    return LANGS.includes(l) ? l : "ko";
  } catch (e) {
    return "ko";
  }
}

function setLang(lang) {
  if (!LANGS.includes(lang) || lang === getLang()) return;
  try { localStorage.setItem(LANG_KEY, lang); } catch (e) {}
  location.reload();
}

/* key: 한국어 원문(또는 의미 단위 키) → { en, ja } */
const I18N = {
  /* ---------- 헤더 / 푸터 / 공용 ---------- */
  "REITEN 홈": { en: "REITEN home", ja: "REITEN ホーム" },
  "주요 메뉴": { en: "Main menu", ja: "メインメニュー" },
  "언어 선택": { en: "Select language", ja: "言語を選択" },
  "야간 주행 모드 전환": { en: "Toggle night-ride mode", ja: "ナイトライドモード切替" },
  "야간 주행 모드": { en: "Night-ride mode", ja: "ナイトライドモード" },
  "장바구니": { en: "Cart", ja: "カート" },
  "메뉴 열기": { en: "Open menu", ja: "メニューを開く" },
  "Reiten — 독일어로 '타다'.<br>말에서 기계로 옮겨 탄 사람들을 위한 옷.": {
    en: "Reiten — German for 'to ride'.<br>Clothing for those who traded reins for a throttle.",
    ja: "Reiten — ドイツ語で「乗る」。<br>手綱からスロットルへ、乗り換えた人たちの服。",
  },
  "전체 상품": { en: "All Products", ja: "全商品" },
  "전체": { en: "All", ja: "すべて" },
  "후드티": { en: "Hoodies", ja: "フーディー" },
  "후드집업": { en: "Zip Hoodies", ja: "ジップフーディー" },
  "크롭 후드티": { en: "Crop Hoodies", ja: "クロップフーディー" },
  "지퍼 참 스튜디오": { en: "Zip Charm Studio", ja: "ジップチャームスタジオ" },
  "브랜드 스토리": { en: "Brand Story", ja: "ブランドストーリー" },
  "룩북 / 라이딩 필름": { en: "Lookbook / Riding Film", ja: "ルックブック / ライディングフィルム" },
  "소재 & 관리법": { en: "Material & Care", ja: "素材とお手入れ" },
  "배송 · 교환 안내": { en: "Shipping & Exchanges", ja: "配送・交換案内" },
  "대표": { en: "CEO", ja: "代表" },
  "사업자등록번호": { en: "Business Reg. No.", ja: "事業者登録番号" },
  "통신판매업신고": { en: "Mail-order Business No.", ja: "通信販売業申告番号" },
  "개인정보관리책임자": { en: "Privacy Officer", ja: "個人情報管理責任者" },
  "사진 준비중": { en: "Photo coming soon", ja: "写真準備中" },
  "{label} 참": { en: "{label} Charm", ja: "{label} チャーム" },
  "후드집업 미리보기 — 선택한 컬러와 지퍼 참이 반영됩니다": {
    en: "Zip hoodie preview — reflects the selected color and zip charm",
    ja: "ジップフーディーのプレビュー — 選択したカラーとジップチャームを反映",
  },

  /* ---------- 홈 ---------- */
  "Reiten — 독일어로 '타다'": { en: "Reiten — German for 'to ride'", ja: "Reiten — ドイツ語で「乗る」" },
  "보이지": { en: "If you're", ja: "見えなければ" },
  "않으면": { en: "not seen,", ja: "" },
  "위험하다": { en: "you're in danger", ja: "危険だ" },
  "말에서 기계로 옮겨 탄 사람들을 위한 옷. 등판 전체에 올린 스카치 리플렉티브 전사는 낮에는 무광 실버 그래픽으로, 밤에는 헤드라이트를 되쏘는 안전 장비로 작동합니다.": {
    en: "Clothing for those who traded reins for a throttle. The Scotch reflective print covering the back reads as matte silver graphics by day, and by night becomes safety gear that bounces headlights straight back.",
    ja: "手綱からスロットルへ、乗り換えた人たちのための服。背中全体にあしらったスコッチ反射転写プリントは、昼間はマットシルバーのグラフィックに見え、夜はヘッドライトを跳ね返す安全装備として機能します。",
  },
  "컬렉션 보기": { en: "Shop Collection", ja: "コレクションを見る" },
  "지퍼 참 만들기": { en: "Build a Zip Charm", ja: "ジップチャームを作る" },
  "남녀공용 오버핏 · S–XL ·": { en: "Unisex oversized · S–XL · Free shipping over", ja: "男女兼用オーバーサイズ · S–XL ·" },
  "이상 무료배송": { en: "", ja: "以上で送料無料" },
  "커서를 올려 빛을 비춰보세요": { en: "Hover to shine a light on it", ja: "カーソルを合わせて光を当ててみてください" },
  "← 빛을 비춰보세요": { en: "← Shine a light on it", ja: "← 光を当ててみてください" },
  "그래픽이 곧<br>안전장비가 된다": { en: "The graphic itself<br>becomes safety gear", ja: "グラフィックが<br>そのまま安全装備になる" },
  "유리 비드가 박힌 재귀반사 필름을 열전사로 올렸습니다. 빛이 들어온 방향으로 그대로 되돌려 보내기 때문에, 마주 오는 차의 헤드라이트 아래에서만 정확히 발광합니다. 리플렉티브 조끼를 따로 걸치지 않아도 되는 이유입니다.": {
    en: "We heat-pressed on a retro-reflective film embedded with glass beads. It sends light straight back the way it came, so it lights up precisely under an oncoming car's headlights — no separate reflective vest required.",
    ja: "ガラスビーズを埋め込んだ再帰反射フィルムを熱転写しました。入ってきた光をそのままの方向へ送り返すため、対向車のヘッドライトの下でのみ正確に発光します。反射ベストを別に羽織る必要がない理由です。",
  },
  "— 3M 스카치라이트 계열 재귀반사 전사": { en: "— 3M Scotchlite-grade retro-reflective transfer", ja: "— 3M スコッチライト系再帰反射転写" },
  "— 480g 헤비 기모 · 워싱 후에도 반사율 유지": { en: "— 480g heavyweight fleece · Reflectivity holds up after washing", ja: "— 480g ヘビー起毛 · 洗濯後も反射率を維持" },
  "— 뒤집어 미온수 손세탁, 프린트 부위 다림질 금지": { en: "— Hand wash inside-out in lukewarm water; never iron the print", ja: "— 裏返してぬるま湯で手洗い、プリント部分へのアイロン禁止" },
  "관리법 자세히 보기": { en: "See full care guide", ja: "お手入れ方法を詳しく見る" },
  "이번 시즌": { en: "This Season", ja: "今シーズン" },
  "전체 보기": { en: "View All", ja: "すべて見る" },
  "같은 옷을 입어도<br>같아 보이지 않게": { en: "Same hoodie,<br>never the same look", ja: "同じ服でも<br>同じに見えないように" },
  "후드집업 지퍼 슬라이더에 다는 참(charm)을 8종 준비했습니다. 컬러와 참을 고르면 화면에서 바로 조합을 확인할 수 있고, 고른 그대로 주문서에 담깁니다. 리플렉티브 실버 마감을 고르면 참도 밤에 빛납니다.": {
    en: "We made 8 charms to hang from the zip hoodie's slider. Pick a color and a charm to preview the combination instantly, and it carries straight into your order exactly as chosen. Pick the reflective silver finish and the charm glows at night too.",
    ja: "ジップフーディーのスライダーに付けるチャームを8種類用意しました。カラーとチャームを選ぶと画面でその場で組み合わせを確認でき、選んだそのまま注文書に反映されます。リフレクティブシルバー仕上げを選べば、チャームも夜に光ります。",
  },
  "스튜디오 열기": { en: "Open the Studio", ja: "スタジオを開く" },
  "라이딩 필름": { en: "Riding Film", ja: "ライディングフィルム" },
  "룩북 전체": { en: "Full Lookbook", ja: "ルックブック全体" },

  /* ---------- Shop ---------- */
  "전 품목 남녀공용 오버핏입니다. 사이즈 실측은 각 상품 페이지에서 확인하세요.": {
    en: "Every item is unisex oversized. Check size measurements on each product page.",
    ja: "全商品が男女兼用オーバーサイズです。サイズ実寸は各商品ページでご確認ください。",
  },
  "해당 카테고리의 상품이 아직 없습니다.": { en: "There are no products in this category yet.", ja: "このカテゴリーの商品はまだありません。" },

  /* ---------- Product ---------- */
  "함께 보면 좋은 것": { en: "You Might Also Like", ja: "あわせて見たい商品" },
  "이미지 {n}": { en: "Image {n}", ja: "画像 {n}" },
  "준비중": { en: "Coming soon", ja: "準備中" },
  "남녀공용 오버핏": { en: "Unisex oversized", ja: "男女兼用オーバーサイズ" },
  "수량 줄이기": { en: "Decrease quantity", ja: "数量を減らす" },
  "수량 늘리기": { en: "Increase quantity", ja: "数量を増やす" },
  "지퍼 참을 함께 고르시겠어요?": { en: "Want to pick a zip charm too?", ja: "ジップチャームも一緒に選びますか？" },
  "이 집업은 지퍼 슬라이더에 참(charm)을 달 수 있습니다.": {
    en: "This zip hoodie lets you hang a charm on the zipper slider.",
    ja: "このジップフーディーは、スライダーにチャームを取り付けられます。",
  },
  "스튜디오에서 조합하기": { en: "Build it in the Studio", ja: "スタジオで組み合わせる" },
  "품절": { en: "Sold Out", ja: "売り切れ" },
  "장바구니 담기": { en: "Add to Cart", ja: "カートに追加" },
  "바로 주문": { en: "Buy Now", ja: "今すぐ注文" },
  "제품 정보": { en: "Product Info", ja: "商品情報" },
  "사이즈 실측 (cm)": { en: "Size Chart (cm)", ja: "サイズ実寸 (cm)" },
  "측정 방식에 따라 1~3cm 오차가 있을 수 있습니다.": { en: "Measurements may vary by 1–3cm depending on method.", ja: "測定方法により1〜3cmの誤差が生じることがあります。" },
  "세탁 · 관리": { en: "Washing & Care", ja: "洗濯・お手入れ" },
  "— 뒤집어서 30℃ 이하 미온수 단독 손세탁을 권장합니다.": { en: "— Hand wash separately, inside-out, in water below 30℃.", ja: "— 裏返して30℃以下のぬるま湯で単独手洗いを推奨します。" },
  "— 리플렉티브 프린트 위에 직접 다림질하지 마세요. 반사층이 손상됩니다.": { en: "— Never iron directly on the reflective print — it damages the reflective layer.", ja: "— リフレクティブプリントに直接アイロンをかけないでください。反射層が傷みます。" },
  "— 건조기·표백제 사용 금지, 그늘에서 뉘어 말리세요.": { en: "— No tumble dryer or bleach — dry flat in the shade.", ja: "— 乾燥機・漂白剤の使用は禁止、日陰で平干ししてください。" },
  "— 드라이클리닝은 프린트 박리의 원인이 됩니다.": { en: "— Dry cleaning can cause the print to peel.", ja: "— ドライクリーニングはプリント剥離の原因になります。" },
  "배송 · 교환/반품": { en: "Shipping & Returns", ja: "配送・交換/返品" },
  "— 배송비 {fee} · {free} 이상 무료": { en: "— Shipping {fee} · Free over {free}", ja: "— 送料 {fee}・{free}以上で無料" },
  "— 배송비 {fee} · {free} 이상 구매 시 무료": { en: "— Shipping {fee} · Free on orders over {free}", ja: "— 送料 {fee}・{free}以上のご購入で無料" },
  "— 단순 변심 교환/반품은 수령 후 7일 이내, 왕복 배송비 고객 부담입니다.": {
    en: "— Change-of-mind exchanges/returns within 7 days of receipt; customer covers round-trip shipping.",
    ja: "— 単純な気変わりによる交換・返品は受取後7日以内、往復送料はお客様負担です。",
  },
  "— 착용·세탁 흔적이 있거나 택을 제거한 경우 교환/반품이 어렵습니다.": {
    en: "— Exchanges/returns aren't possible if the item shows signs of wear/washing or the tag has been removed.",
    ja: "— 着用・洗濯の跡がある場合やタグを外した場合は交換・返品が難しくなります。",
  },
  "컬러": { en: "Color", ja: "カラー" },
  "사이즈": { en: "Size", ja: "サイズ" },
  "{name} · {size} 담았습니다": { en: "Added {name} · {size} to cart", ja: "{name}・{size}をカートに追加しました" },

  /* ---------- Lookbook ---------- */
  "낮과 밤,<br>두 벌처럼 입는 한 벌": { en: "Day and night,<br>one piece that wears like two", ja: "昼と夜、<br>二着のように着る一着" },
  "같은 옷이 조명 아래에서 어떻게 달라지는지 기록합니다. 룩북과 라이딩 필름 스틸은 촬영이 끝나는 대로 이 자리에 채워집니다.": {
    en: "A record of how the same garment changes under different light. Lookbook and riding-film stills will fill this space as soon as shooting wraps.",
    ja: "同じ服が光の下でどう変わるかを記録します。ルックブックとライディングフィルムのスチールは、撮影が終わり次第この場所に追加されます。",
  },
  "촬영 준비 중": { en: "Shoot in Progress", ja: "撮影準備中" },
  "아래 칸은 실제 사진이 들어갈 자리입니다. 각 칸의 비율에 맞춰 이미지를 준비해 주세요.": {
    en: "The tiles below are placeholders for real photos. Prepare images matching each tile's aspect ratio.",
    ja: "下の枠は実際の写真が入る場所です。各枠の比率に合わせて画像をご用意ください。",
  },
  "배열에": { en: "array — add", ja: "配列に" },
  "를 추가하면 자동으로 채워집니다.": { en: " and it fills in automatically.", ja: " を追加すると自動的に反映されます。" },

  /* ---------- About ---------- */
  "말에서 기계로<br>옮겨 탄 사람들": { en: "From horseback<br>to the throttle", ja: "馬から機械へ<br>乗り換えた人々" },
  "Reiten [ˈʁaɪtn̩] — 독일어로 '타다'. 고삐를 쥐던 손이 스로틀을 쥐게 된 것뿐, 달리고 싶다는 마음은 바뀌지 않았습니다.": {
    en: "Reiten [ˈʁaɪtn̩] — German for 'to ride'. The hand that once held the reins now grips a throttle — the will to ride never changed.",
    ja: "Reiten [ˈʁaɪtn̩] — ドイツ語で「乗る」。手綱を握っていた手がスロットルを握るようになっただけで、走りたいという気持ちは変わりません。",
  },
  "브랜드 이름에 말이 있는 이유": { en: "Why there's a horse in our name", ja: "ブランド名に馬がいる理由" },
  "독일에서 <i>reiten</i>은 원래 말을 타는 것을 뜻하는 동사입니다. 지금은 오토바이를 타는 일에도 같은 단어를 씁니다. 수백 년 사이에 타는 대상은 바뀌었지만 단어는 그대로 남았습니다.": {
    en: "In German, <i>reiten</i> originally meant to ride a horse. Today the same word is used for riding a motorcycle. Over hundreds of years, what we ride changed — the word stayed the same.",
    ja: "ドイツ語で<i>reiten</i>はもともと馬に乗ることを意味する動詞です。今ではオートバイに乗ることにも同じ言葉が使われます。数百年の間に乗るものは変わりましたが、言葉はそのまま残りました。",
  },
  "우리는 그 지점이 좋았습니다. 로고에 말과 바이크를 나란히 세운 것도 같은 이유입니다. REITEN은 특정 기종이나 배기량, 라이딩 스타일을 나누지 않습니다. 남녀 구분 없이 한 벌을 만들고, 사이즈로만 나눕니다.": {
    en: "We loved that. It's why our logo sets a horse and a bike side by side. REITEN doesn't divide by model, engine size, or riding style. We make one garment for everyone and split it only by size.",
    ja: "私たちはその点が気に入りました。ロゴに馬とバイクを並べたのも同じ理由です。REITENは車種や排気量、ライディングスタイルで分けません。男女の区別なく一着を作り、サイズだけで分けます。",
  },
  "멋있어 보이는 옷과 안전한 옷 중에 하나를 고르게 하고 싶지 않았습니다. 그래서 그래픽 자체를 반사재로 만들었습니다.": {
    en: "We didn't want to make you choose between looking good and staying safe. So we made the graphic itself the reflective material.",
    ja: "かっこいい服と安全な服のどちらかを選ばせたくありませんでした。だからグラフィック自体を反射素材にしました。",
  },
  "되돌려 보내는 빛": { en: "Light, sent back", ja: "送り返す光" },
  "일반적인 흰색 프린트는 빛을 사방으로 흩뿌립니다. 재귀반사(retro-reflective) 소재는 미세한 유리 비드가 들어 있어, 들어온 빛을 <b>온 방향 그대로</b> 되돌려 보냅니다. 그래서 마주 오는 운전자의 시점에서만 강하게 빛나고, 옆에서 보면 무광 실버로 보입니다.": {
    en: "An ordinary white print scatters light in every direction. Retro-reflective material contains microscopic glass beads that send incoming light <b>straight back the way it came</b>. That's why it glows strongly only from an oncoming driver's point of view, and reads as matte silver from the side.",
    ja: "通常の白プリントは光を四方に散らします。再帰反射素材は微細なガラスビーズを含んでおり、入ってきた光を<b>そのままの方向へ</b>送り返します。だから対向するドライバーの視点でのみ強く光り、横から見るとマットシルバーに見えます。",
  },
  "반사 조끼를 한 겹 더 걸치는 대신, 입고 있던 후디의 그래픽이 그 일을 합니다. 디자인을 포기하지 않아도 되는 방식입니다.": {
    en: "Instead of layering on a reflective vest, the graphic on the hoodie you're already wearing does the job. A way to stay safe without giving up on design.",
    ja: "反射ベストをもう一枚羽織る代わりに、着ているフーディーのグラフィックがその役割を果たします。デザインを諦めなくていい方法です。",
  },
  "원단": { en: "Fabric", ja: "生地" },
  "— 후디 : 코튼 80% / 폴리 20%, 480g 헤비 기모": { en: "— Hoodie: 80% cotton / 20% poly, 480g heavyweight fleece", ja: "— フーディー：コットン80％／ポリ20％、480gヘビー起毛" },
  "— 집업 : 코튼 100%, 420g (일부 가먼트 워싱)": { en: "— Zip hoodie: 100% cotton, 420g (garment-washed on select styles)", ja: "— ジップフーディー：コットン100％、420g（一部ガーメントウォッシュ）" },
  "— 립 조직 밑단 · 소매, 3겹 후드": { en: "— Ribbed hem & cuffs, 3-layer hood", ja: "— リブ編みの裾・袖、3層フード" },
  "— 남녀공용 오버핏, 드롭숄더 패턴": { en: "— Unisex oversized fit, drop-shoulder pattern", ja: "— 男女兼用オーバーサイズ、ドロップショルダーパターン" },
  "세탁": { en: "Washing", ja: "洗濯" },
  "— 뒤집어서 30℃ 이하 미온수 단독 세탁": { en: "— Wash inside-out, separately, below 30℃", ja: "— 裏返して30℃以下のぬるま湯で単独洗い" },
  "— 중성세제 사용, 표백제 금지": { en: "— Use neutral detergent, no bleach", ja: "— 中性洗剤を使用、漂白剤は禁止" },
  "— 세탁기 사용 시 세탁망 + 울코스": { en: "— If machine washing, use a laundry bag on the wool/delicate cycle", ja: "— 洗濯機使用時は洗濯ネット＋ウールコース" },
  "— 건조기 금지, 그늘에서 뉘어 건조": { en: "— No tumble dryer — dry flat in the shade", ja: "— 乾燥機は禁止、日陰で平干し" },
  "프린트 보호": { en: "Print Protection", ja: "プリント保護" },
  "— 프린트 위 직접 다림질 금지 (반사층 손상)": { en: "— Never iron directly on the print (damages the reflective layer)", ja: "— プリントへの直接のアイロンは禁止（反射層が傷みます）" },
  "— 구김은 뒷면에서 저온으로, 천을 덧대어": { en: "— For wrinkles, iron on the reverse at low heat with a cloth in between", ja: "— シワは裏面から低温で、当て布をして" },
  "— 드라이클리닝은 박리의 원인이 됩니다": { en: "— Dry cleaning can cause peeling", ja: "— ドライクリーニングは剥離の原因になります" },
  "— 접어 보관보다 걸어 보관을 권장합니다": { en: "— Hanging storage is recommended over folding", ja: "— 畳んでの保管より、吊るしての保管を推奨します" },
  "배송 · 교환 · 반품": { en: "Shipping, Exchanges & Returns", ja: "配送・交換・返品" },
  "배송": { en: "Shipping", ja: "配送" },
  "— 제주 · 도서산간 지역은 추가 배송비가 발생합니다.": { en: "— Additional shipping fees apply to Jeju and other remote island/mountain areas.", ja: "— 済州・離島地域は追加送料が発生します。" },
  "— 주문 폭주 · 원단 수급 상황에 따라 출고가 지연될 수 있으며, 지연 시 개별 안내드립니다.": {
    en: "— Shipping may be delayed during high order volume or fabric supply issues; we'll notify you individually if it happens.",
    ja: "— 注文の集中・生地の入荷状況により発送が遅れる場合があり、その際は個別にご案内します。",
  },
  "교환 · 반품": { en: "Exchanges & Returns", ja: "交換・返品" },
  "— 단순 변심 : 수령일로부터 7일 이내 접수, 왕복 배송비 고객 부담": { en: "— Change of mind: request within 7 days of receipt, customer covers round-trip shipping", ja: "— 単純な気変わり：受取日から7日以内に受付、往復送料はお客様負担" },
  "— 상품 하자 · 오배송 : 수령일로부터 30일 이내, 배송비 전액 판매자 부담": { en: "— Defects or wrong item: within 30 days of receipt, seller covers shipping in full", ja: "— 商品の不良・誤配送：受取日から30日以内、送料は全額販売者負担" },
  "— 착용 · 세탁 흔적이 있거나 택을 제거한 경우 교환 · 반품이 제한됩니다.": { en: "— Exchanges/returns are restricted if the item shows wear/wash marks or the tag has been removed.", ja: "— 着用・洗濯の跡がある場合やタグを外した場合は交換・返品が制限されます。" },
  "— 지퍼 참을 조합한 커스텀 주문도 위 기준을 동일하게 적용합니다.": { en: "— Custom orders with a zip charm combination follow the same criteria above.", ja: "— ジップチャームを組み合わせたカスタム注文も上記基準を同様に適用します。" },
  "— 접수는 고객센터 이메일 또는 카카오톡 채널로 주문번호와 함께 남겨주세요.": { en: "— Submit requests with your order number via our customer service email or KakaoTalk channel.", ja: "— お問い合わせは注文番号とともにカスタマーサポートのメールまたはカカオトークチャンネルへご連絡ください。" },
  "사이즈 선택": { en: "Choosing a Size", ja: "サイズの選び方" },
  "전 품목 남녀공용 오버핏입니다. 평소 사이즈 그대로 고르시면 넉넉하게 맞습니다.": { en: "Every item is unisex oversized. Your usual size will fit generously.", ja: "全商品が男女兼用オーバーサイズです。普段のサイズをそのまま選ぶとゆったり着られます。" },
  "판매자 정보": { en: "Seller Information", ja: "販売者情報" },
  "상호": { en: "Company", ja: "商号" },
  "대표자": { en: "CEO", ja: "代表者" },
  "사업장 주소": { en: "Business Address", ja: "事業所住所" },
  "연락처": { en: "Contact", ja: "連絡先" },
  "이메일": { en: "Email", ja: "メール" },

  /* ---------- Cart / Order ---------- */
  "장바구니가 비어 있습니다.": { en: "Your cart is empty.", ja: "カートは空です。" },
  "컬렉션 보러 가기": { en: "Browse the Collection", ja: "コレクションを見に行く" },
  "주문서": { en: "Order Form", ja: "注文フォーム" },
  "아래 정보를 남기시면 주문번호가 발급됩니다. 입금이 확인되면 순차 출고됩니다.": {
    en: "Fill in the details below to receive an order number. Items ship in order once payment is confirmed.",
    ja: "以下の情報をご入力いただくと注文番号が発行されます。ご入金確認後、順次発送します。",
  },
  '주문자 이름 <span class="req">*</span>': { en: 'Full name <span class="req">*</span>', ja: 'お名前 <span class="req">*</span>' },
  "이름을 입력해 주세요.": { en: "Please enter your name.", ja: "お名前をご入力ください。" },
  '연락처 <span class="req">*</span>': { en: 'Phone number <span class="req">*</span>', ja: '電話番号 <span class="req">*</span>' },
  "연락처를 정확히 입력해 주세요.": { en: "Please enter a valid phone number.", ja: "正しい電話番号をご入力ください。" },
  '이메일 <span class="req">*</span>': { en: 'Email <span class="req">*</span>', ja: 'メールアドレス <span class="req">*</span>' },
  "주문 확인 메일을 받을 주소": { en: "Address to receive order confirmation", ja: "注文確認メールを受け取るアドレス" },
  "이메일 형식을 확인해 주세요.": { en: "Please check your email format.", ja: "メールアドレスの形式をご確認ください。" },
  '우편번호 <span class="req">*</span>': { en: 'Postal code <span class="req">*</span>', ja: '郵便番号 <span class="req">*</span>' },
  "우편번호를 입력해 주세요.": { en: "Please enter your postal code.", ja: "郵便番号をご入力ください。" },
  '입금자명 <span class="req">*</span>': { en: 'Depositor name <span class="req">*</span>', ja: 'お振込み名義 <span class="req">*</span>' },
  "입금자명을 입력해 주세요.": { en: "Please enter the depositor's name.", ja: "お振込み名義をご入力ください。" },
  '주소 <span class="req">*</span>': { en: 'Address <span class="req">*</span>', ja: 'ご住所 <span class="req">*</span>' },
  "주소를 입력해 주세요.": { en: "Please enter your address.", ja: "ご住所をご入力ください。" },
  "상세주소": { en: "Address line 2", ja: "詳細住所" },
  "동 · 호수 등": { en: "Apt, unit, etc.", ja: "建物名・号室など" },
  "배송 메모": { en: "Delivery note", ja: "配送メモ" },
  "부재 시 문 앞에 놓아주세요 등": { en: "e.g. Leave at the door if I'm out", ja: "例：不在時は玄関前に置いてください" },
  '주문 처리를 위한 개인정보(이름 · 연락처 · 주소) 수집 및 이용에 동의합니다. 수집한 정보는 배송 완료 후 관련 법령이 정한 기간까지만 보관합니다. <span class="req">*</span>': {
    en: 'I agree to the collection and use of personal information (name, phone, address) for order processing. Information is retained only for the period required by law after delivery is complete. <span class="req">*</span>',
    ja: '注文処理のための個人情報（氏名・連絡先・住所）の収集及び利用に同意します。収集した情報は配送完了後、関連法令が定める期間のみ保管します。 <span class="req">*</span>',
  },
  "동의가 필요합니다.": { en: "Agreement is required.", ja: "同意が必要です。" },
  "주문서 제출": { en: "Submit Order", ja: "注文を送信" },
  "결제 금액": { en: "Payment Summary", ja: "お支払い金額" },
  "상품 합계": { en: "Subtotal", ja: "商品合計" },
  "배송비": { en: "Shipping", ja: "送料" },
  "총 결제금액": { en: "Total", ja: "合計金額" },
  "무통장 입금": { en: "Bank Transfer", ja: "銀行振込" },
  "예금주": { en: "Account holder", ja: "口座名義" },
  "주문서 제출 후 3일 내 미입금 시 자동 취소됩니다.": { en: "If payment isn't received within 3 days of submitting, the order is automatically cancelled.", ja: "注文送信後3日以内にご入金がない場合、自動的にキャンセルされます。" },
  "무료": { en: "Free", ja: "無料" },
  "{amount} 더 담으면 배송비가 무료입니다.": { en: "Add {amount} more for free shipping.", ja: "あと{amount}で送料無料になります。" },
  "제출하면 주문서가 바로 전송됩니다.": { en: "Submitting sends your order form immediately.", ja: "送信すると注文フォームがすぐに送られます。" },
  "제출하면 주문번호와 함께 복사용 주문서가 만들어집니다. 이메일 또는 카카오톡으로 보내주세요.": {
    en: "Submitting creates an order number and a copyable order form. Please send it to us by email or KakaoTalk.",
    ja: "送信すると注文番号と、コピー用の注文書が作成されます。メールまたはカカオトークで送ってください。",
  },
  "입력값을 확인해 주세요": { en: "Please check your entries", ja: "入力内容をご確認ください" },
  "장바구니가 비어 있습니다": { en: "Your cart is empty", ja: "カートは空です" },
  "처리 중…": { en: "Processing…", ja: "処理中…" },
  "삭제": { en: "Remove", ja: "削除" },
  "개당 {price}": { en: "{price} each", ja: "1点あたり {price}" },

  /* ---------- Order complete ---------- */
  "표시할 주문 내역이 없습니다.": { en: "There's no order to show.", ja: "表示できる注文内容がありません。" },
  "주문이 접수되었습니다": { en: "Your order has been received", ja: "ご注文を承りました" },
  "주문번호": { en: "Order No.", ja: "注文番号" },
  "{name}님": { en: "{name}", ja: "{name} 様" },
  "입금 안내": { en: "Payment Instructions", ja: "お振込みのご案内" },
  "입금액": { en: "Amount", ja: "入金額" },
  "입금자명": { en: "Depositor", ja: "振込名義" },
  "3일 내 미입금 시 주문은 자동 취소됩니다. {leadTime}.": { en: "If payment isn't received within 3 days, the order is automatically cancelled. {leadTime}.", ja: "3日以内にご入金がない場合、注文は自動的にキャンセルされます。{leadTime}。" },
  "주문서가 정상적으로 전송되었습니다. 확인 후 개별 연락드리겠습니다.": { en: "Your order form was sent successfully. We'll be in touch individually after review.", ja: "注文書は正常に送信されました。確認後、個別にご連絡いたします。" },
  "주문서를 보내주세요": { en: "Please send us your order form", ja: "注文書をお送りください" },
  "아래 주문서를 복사해 이메일 또는 카카오톡으로 보내주시면 접수가 완료됩니다.": {
    en: "Copy the order form below and send it by email or KakaoTalk to complete your order.",
    ja: "下記の注文書をコピーし、メールまたはカカオトークで送っていただくと受付が完了します。",
  },
  "주문서 복사": { en: "Copy Order Form", ja: "注文書をコピー" },
  "이메일로 열기": { en: "Open in Email", ja: "メールで開く" },
  "주문 내역": { en: "Order Details", ja: "注文内容" },
  "상품": { en: "Item", ja: "商品" },
  "옵션": { en: "Options", ja: "オプション" },
  "수량": { en: "Qty", ja: "数量" },
  "금액": { en: "Amount", ja: "金額" },
  "주문서 원문 보기": { en: "View Raw Order Text", ja: "注文書の原文を見る" },
  "쇼핑 계속하기": { en: "Continue Shopping", ja: "ショッピングを続ける" },
  "홈으로": { en: "Home", ja: "ホームへ" },
  "주문서를 복사했습니다": { en: "Order form copied", ja: "注文書をコピーしました" },
  "주문서를 선택했습니다. 복사해 주세요": { en: "Order text selected — please copy it", ja: "注文書を選択しました。コピーしてください" },

  /* ---------- Customizer ---------- */
  "지퍼 참 만들기": { en: "Build Your Zip Charm", ja: "ジップチャームを作る" },
  "컬러와 참을 고르면 왼쪽 미리보기에 바로 반영됩니다. <b>라이트</b> 스위치를 켜면 야간 주행 상황에서 어떻게 보이는지 확인할 수 있습니다.": {
    en: "Pick a color and charm and it reflects instantly in the preview on the left. Flip the <b>Light</b> switch to see how it looks while night riding.",
    ja: "カラーとチャームを選ぶと、左側のプレビューにすぐ反映されます。<b>ライト</b>スイッチをオンにすると、夜間走行時の見え方を確認できます。",
  },
  "라이트": { en: "Light", ja: "ライト" },
  "* 미리보기는 조합 확인용 벡터 이미지입니다. 실제 제품의 색상 · 광택과 차이가 있을 수 있습니다.": {
    en: "* The preview is a vector image for checking combinations. Actual color and sheen may differ.",
    ja: "※ プレビューは組み合わせ確認用のベクター画像です。実際の商品とは色・光沢が異なる場合があります。",
  },
  "합계": { en: "Total", ja: "合計" },
  "참만 따로 구매": { en: "Buy a charm on its own", ja: "チャームだけ購入" },
  "이미 REITEN 집업을 갖고 계시다면 참만 구매할 수 있습니다. 개당": { en: "Already own a REITEN zip hoodie? You can buy just the charm. Each is", ja: "すでにREITENのジップフーディーをお持ちなら、チャームだけ購入できます。1個あたり" },
  "참만 담기": { en: "Add Charm Only", ja: "チャームのみカートに追加" },
  "참 8종": { en: "8 Charms", ja: "チャーム8種" },
  "전 품목 개당": { en: "Each charm is", ja: "全品1個あたり" },
  "· 리플렉티브 실버 / 매트 블랙 / 컬러": { en: "· Reflective Silver / Matte Black / Color", ja: "・リフレクティブシルバー／マットブラック／カラー" },
  "참 없음": { en: "No charm", ja: "チャームなし" },
  "지퍼 참 (선택 안 함)": { en: "Zip Charm (none selected)", ja: "ジップチャーム（選択なし）" },
  "지퍼 참 — {charm}": { en: "Zip Charm — {charm}", ja: "ジップチャーム — {charm}" },
  "조합을 장바구니에 담았습니다": { en: "Added this combination to your cart", ja: "組み合わせをカートに追加しました" },
  "먼저 참을 선택해 주세요": { en: "Please choose a charm first", ja: "先にチャームを選択してください" },
  "참을 장바구니에 담았습니다": { en: "Added the charm to your cart", ja: "チャームをカートに追加しました" },
  "지퍼 참": { en: "Zip Charm", ja: "ジップチャーム" },
  "마감": { en: "Finish", ja: "仕上げ" },
  "선택 안 함": { en: "None selected", ja: "選択なし" },

  /* ---------- 상품 데이터 (data.js) ---------- */
  "리플렉트 하트 후디": { en: "Reflect Heart Hoodie", ja: "リフレクトハートフーディー" },
  "트라이벌 하트 스카치 전사 · 백 프린트": { en: "Tribal heart Scotch transfer · back print", ja: "トライバルハート スコッチ転写・バックプリント" },
  "등판 전체에 스카치라이트 리플렉티브 전사를 올린 헤비 후디입니다. 낮에는 무광 실버 그래픽으로 보이고, 야간 주행 중 헤드라이트를 받으면 그래픽 전체가 발광합니다.": {
    en: "A heavyweight hoodie with a Scotchlite reflective transfer covering the entire back. It reads as matte silver graphics by day, and lights up entirely under headlights during a night ride.",
    ja: "背面全体にスコッチライト反射転写をあしらったヘビーウェイトフーディー。昼はマットシルバーのグラフィックに見え、夜間走行中にヘッドライトを受けるとグラフィック全体が発光します。",
  },
  "리플렉트 이그저스트 후디": { en: "Reflect Exhaust Hoodie", ja: "リフレクトエキゾーストフーディー" },
  "머플러 & 플레임 스카치 전사 · 백 프린트": { en: "Muffler & flame Scotch transfer · back print", ja: "マフラー＆フレイム スコッチ転写・バックプリント" },
  "배기 머플러와 화염을 라인 드로잉으로 옮긴 백 그래픽. 라인이 가늘수록 반사 대비가 강해져서, 어두울수록 그림이 또렷해집니다.": {
    en: "A back graphic that renders an exhaust muffler and flames as line art. The thinner the lines, the stronger the reflective contrast — the darker it gets, the sharper the image.",
    ja: "排気マフラーと炎をラインドローイングで表現したバックグラフィック。線が細いほど反射のコントラストが強くなり、暗いほど絵がくっきり浮かび上がります。",
  },
  "헬멧 집업 후디": { en: "Helmet Zip Hoodie", ja: "ヘルメットジップフーディー" },
  "가먼트 워싱 · 프론트 드로잉 그래픽": { en: "Garment-washed · front line-art graphic", ja: "ガーメントウォッシュ・フロントドローイング" },
  "완성 후 워싱을 먹여 색이 한 톤 빠진 집업입니다. 가슴의 헬멧 드로잉과 소매 로고는 리플렉티브 전사로, 정면에서 빛을 받으면 그래픽만 떠오릅니다.": {
    en: "A zip hoodie garment-washed after construction for a slightly faded tone. The chest helmet drawing and sleeve logo are reflective transfers that appear to float when lit from the front.",
    ja: "縫製後にウォッシュ加工を施し、色味を一段階抜いたジップフーディー。胸のヘルメットドローイングと袖のロゴはリフレクティブ転写で、正面から光を受けるとグラフィックだけが浮かび上がります。",
  },
  "코어 집업 후디": { en: "Core Zip Hoodie", ja: "コアジップフーディー" },
  "6컬러 · 지퍼 참 커스텀 가능": { en: "6 colors · zip charm customizable", ja: "6カラー・ジップチャームカスタム可能" },
  "브랜드의 기본이 되는 집업입니다. 그래픽 없이 소매의 리플렉티브 스크립트 로고만 남겼습니다. 지퍼 슬라이더에 원하는 참(charm)을 달아 조합을 완성하세요.": {
    en: "The brand's foundational zip hoodie. No graphics — just a reflective script logo on the sleeve. Hang the charm of your choice on the zip slider to complete the look.",
    ja: "ブランドの基本となるジップフーディー。グラフィックはなく、袖のリフレクティブスクリプトロゴのみを残しました。ジップスライダーにお好みのチャームを付けて組み合わせを完成させてください。",
  },
  "리플렉트 크롭 후디": { en: "Reflect Crop Hoodie", ja: "リフレクトクロップフーディー" },
  "숏 기장 · 라이딩 자세 기준 패턴": { en: "Cropped length · pattern cut for riding posture", ja: "ショート丈・ライディング姿勢基準パターン" },
  "탱크에 엎드린 자세에서 밑단이 말려 올라가지 않도록 앞뒤 기장 차를 둔 크롭 후디입니다. 촬영 준비 중이며 사진은 곧 업데이트됩니다.": {
    en: "A crop hoodie with a front-back length difference so the hem doesn't ride up when leaning over the tank. Photos are being shot and will be updated soon.",
    ja: "タンクに伏せた姿勢でも裾がまくれ上がらないよう、前後の丈に差をつけたクロップフーディー。撮影準備中のため、写真は近日更新予定です。",
  },
  "겉감 : 코튼 80% / 폴리에스터 20% · 480g 헤비 기모": { en: "Shell: 80% cotton / 20% polyester · 480g heavyweight fleece", ja: "表地：コットン80％／ポリエステル20％・480gヘビー起毛" },
  "프린팅 : 3M 스카치라이트 계열 리플렉티브 전사": { en: "Print: 3M Scotchlite-grade reflective transfer", ja: "プリント：3M スコッチライト系リフレクティブ転写" },
  "핏 : 남녀공용 오버핏 (드롭숄더)": { en: "Fit: Unisex oversized (drop shoulder)", ja: "フィット：男女兼用オーバーサイズ（ドロップショルダー）" },
  "부자재 : 두께감 있는 3겹 후드, 립 조직 밑단": { en: "Trims: Substantial 3-layer hood, ribbed hem", ja: "付属：厚みのある3層フード、リブ編みの裾" },
  "겉감 : 코튼 100% · 420g 가먼트 워싱": { en: "Shell: 100% cotton · 420g, garment-washed", ja: "表地：コットン100％・420g ガーメントウォッシュ" },
  "프린팅 : 리플렉티브 전사 (프론트 · 소매)": { en: "Print: Reflective transfer (front · sleeve)", ja: "プリント：リフレクティブ転写（フロント・袖）" },
  "부자재 : YKK 양방향 지퍼 · 참(charm) 탈부착 가능": { en: "Trims: YKK two-way zipper · charm attaches/detaches", ja: "付属：YKK両開きジッパー・チャーム着脱可能" },
  "겉감 : 코튼 100% · 420g": { en: "Shell: 100% cotton · 420g", ja: "表地：コットン100％・420g" },
  "프린팅 : 소매 리플렉티브 스크립트 로고": { en: "Print: Reflective script logo on sleeve", ja: "プリント：袖のリフレクティブスクリプトロゴ" },
  "겉감 : 코튼 80% / 폴리에스터 20% · 400g": { en: "Shell: 80% cotton / 20% polyester · 400g", ja: "表地：コットン80％／ポリエステル20％・400g" },
  "프린팅 : 리플렉티브 전사": { en: "Print: Reflective transfer", ja: "プリント：リフレクティブ転写" },
  "핏 : 여유 있는 크롭 (남녀공용)": { en: "Fit: Relaxed crop (unisex)", ja: "フィット：ゆったりクロップ（男女兼用）" },
  "부자재 : 립 조직 밑단": { en: "Trims: Ribbed hem", ja: "付属：リブ編みの裾" },

  "블랙": { en: "Black", ja: "ブラック" },
  "워시드 차콜": { en: "Washed Charcoal", ja: "ウォッシュドチャコール" },
  "크림": { en: "Cream", ja: "クリーム" },
  "스카이 블루": { en: "Sky Blue", ja: "スカイブルー" },
  "포레스트": { en: "Forest", ja: "フォレスト" },
  "클레이": { en: "Clay", ja: "クレイ" },

  "사이즈": { en: "Size", ja: "サイズ" },
  "총장": { en: "Length", ja: "着丈" },
  "가슴단면": { en: "Chest", ja: "身幅" },
  "어깨": { en: "Shoulder", ja: "肩幅" },
  "소매길이": { en: "Sleeve", ja: "袖丈" },

  "리플렉티브 실버": { en: "Reflective Silver", ja: "リフレクティブシルバー" },
  "빛을 받으면 발광": { en: "Glows when lit", ja: "光を受けると発光" },
  "매트 블랙": { en: "Matte Black", ja: "マットブラック" },
  "무광 메탈": { en: "Matte metal", ja: "マット仕上げのメタル" },
  "에나멜 도장": { en: "Enamel finish", ja: "エナメル塗装" },

  "없음": { en: "None", ja: "なし" },
  "스타": { en: "Star", ja: "スター" },
  "체리": { en: "Cherry", ja: "チェリー" },
  "헬멧": { en: "Helmet", ja: "ヘルメット" },
  "말굽": { en: "Horseshoe", ja: "蹄鉄" },
  "플레임": { en: "Flame", ja: "フレイム" },
  "트라이벌 하트": { en: "Tribal Heart", ja: "トライバルハート" },
  "볼트": { en: "Bolt", ja: "ボルト" },
  "키": { en: "Key", ja: "キー" },

  "01 — Night Ride / 남산": { en: "01 — Night Ride / Namsan", ja: "01 — ナイトライド／南山" },
  "02 — Detail / 지퍼 참": { en: "02 — Detail / Zip Charm", ja: "02 — ディテール／ジップチャーム" },
  "헤드라이트 반사 컷": { en: "Headlight reflection shot", ja: "ヘッドライト反射カット" },
  "클로즈업": { en: "Close-up", ja: "クローズアップ" },
  "주간 / 야간 대비": { en: "Day / night contrast", ja: "昼間／夜間の対比" },
  "라이딩 자세": { en: "Riding posture", ja: "ライディング姿勢" },
  "컬러 랩업": { en: "Color lineup", ja: "カラーラインナップ" },
  "라이딩 필름 캡처": { en: "Riding film capture", ja: "ライディングフィルムキャプチャー" },
  "남녀 스타일링": { en: "His & hers styling", ja: "メンズ＆レディーススタイリング" },
  "정비 컷": { en: "Garage shot", ja: "整備カット" },

  "결제 확인 후 2~5 영업일 이내 출고": { en: "Ships within 2–5 business days after payment is confirmed", ja: "ご入金確認後2〜5営業日以内に発送" },
};

/**
 * t("한국어 원문", { name: "값" })
 * - ko 상태: {var} 치환만 하고 그대로 반환
 * - en/ja 상태: 딕셔너리에 있으면 번역, 없으면 한국어 원문으로 폴백
 */
function t(key, vars) {
  const lang = getLang();
  let s = key;
  if (lang !== "ko" && I18N[key] && typeof I18N[key][lang] === "string") s = I18N[key][lang];
  if (vars) {
    Object.keys(vars).forEach((k) => {
      s = s.replaceAll(`{${k}}`, vars[k]);
    });
  }
  return s;
}

/* 정적 HTML에 남아 있는 텍스트 치환 — data-i18n="키" / data-i18n-html(innerHTML 허용) / data-i18n-attr="attr:키|attr2:키2" */
function applyI18n(root = document) {
  if (getLang() === "ko") return;
  root.querySelectorAll("[data-i18n]").forEach((el) => {
    const val = t(el.dataset.i18n);
    if (el.hasAttribute("data-i18n-html")) el.innerHTML = val;
    else el.textContent = val;
  });
  root.querySelectorAll("[data-i18n-attr]").forEach((el) => {
    el.dataset.i18nAttr.split("|").forEach((pair) => {
      const i = pair.indexOf(":");
      const attr = pair.slice(0, i);
      const key = pair.slice(i + 1);
      el.setAttribute(attr, t(key));
    });
  });
}

document.documentElement.lang = getLang();
